public class Car {
    private String AA;      // 车型
    private String  B;      // 车牌

    public void setAA(String AA) {
        this.AA = AA;
    }
    public String getAA() { return AA; }

    public void setB(String B) {
        this.B = B;
    }
    public String getB() { return B; }

    public void start(){
        System.out.println("我是车，我启动");
    }
    public void stop() {
        System.out.println("我是车，我停止");
    }
}
