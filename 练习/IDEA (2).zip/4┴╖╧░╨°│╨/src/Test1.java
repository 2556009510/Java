public class Test1 {
    public static void main(String[] args) {
        Car c = new Car();
        c.start();
        c.stop();
        System.out.println("============================");

/** FamilyCar方法中不能用void，否则写不了"武大郎666" */
        FamilyCar f = new FamilyCar("武大郎666");
        f.start();
        f.stop();
        System.out.println("============================");

/** Taxi方法中不能用void，否则写不了"大佬666" */
        Taxi t = new Taxi("大佬666");
        t.setB("川A666666");
        t.start();
        t.stop();
    }
}
