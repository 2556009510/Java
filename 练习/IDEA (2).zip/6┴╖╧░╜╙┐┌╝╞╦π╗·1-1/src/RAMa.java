public class RAMa implements RAM {

    @Override
    public String RAMcapacity() { return "4G"; }
}
