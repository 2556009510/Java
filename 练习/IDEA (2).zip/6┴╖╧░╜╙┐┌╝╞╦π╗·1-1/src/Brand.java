public class Brand implements CPU{

    @Override
    public String Brand() { return "intel"; }
    @Override
    public String GH() { return "3.8G"; }
}
