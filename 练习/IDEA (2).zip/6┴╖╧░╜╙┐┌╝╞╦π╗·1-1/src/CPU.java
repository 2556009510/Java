public interface CPU {
    public String Brand();
    public String GH();
}
