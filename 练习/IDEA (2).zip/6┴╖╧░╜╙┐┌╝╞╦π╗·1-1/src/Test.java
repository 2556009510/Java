public class Test {
    public static void main(String[] args) {
        Computer c = new Computer();
        CPU cpu = new Brand(); /** 接口 对 被接口 */
        GB gb = new GB1();     /** 直接将 GBa 换成 GB1 参数就可以改 */
        RAM ram = new RAMa();
        c.show(cpu,gb,ram);  /** Computer类里的show方法 */
    }
}
