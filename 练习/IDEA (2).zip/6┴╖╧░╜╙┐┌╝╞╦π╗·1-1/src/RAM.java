public interface RAM {
    public String RAMcapacity();
}
