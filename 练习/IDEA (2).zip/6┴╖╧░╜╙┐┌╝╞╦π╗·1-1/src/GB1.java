public class GB1 implements GB{

    @Override
    public String GBcapacity() { return "200G"; }
}
