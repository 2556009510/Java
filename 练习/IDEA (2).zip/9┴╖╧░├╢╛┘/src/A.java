public enum A {
//    男,女;
}
