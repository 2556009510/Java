
public class AText {

//    A a1 = A.女;
//    A a2 = A.男;

    public static void main(String[] args) {
        B b = B.AAA;

        String name = B.BBB.name();
        System.out.println(name);

        b.show();
    }
}
