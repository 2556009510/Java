public enum  B {

    AAA("aaa"),BBB("bbb"),CCC("ccc");

    B(String name) {
        this.name = name;
    }

    private String name;
    public void show() {
        System.out.println(this.name);
        B[] b = values();
        for (int i = 0; i < b.length; i++) {
            System.out.println(b[i]);

        }
    }
}

