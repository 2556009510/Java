package aaa;

public class TestExtends {
    public static void main(String[] args) {
        Mammal m1 = new Mammal();
        m1.puru();
        m1.eat();
    }
}
class Animal {
    String eyes="眼睛";
    String name="无名";

    public void eat(){
        System.out.println("动物吃东西！");
    }
}

class Mammal extends Animal {

    public void puru(){
        eyes="嘴巴";
        System.out.println("小动物吃奶！");
    }
}