package com.mashibing;

public abstract class Pet {
    public abstract void feed();

    public void play(){
        System.out.println("playing.....");
    }
}
