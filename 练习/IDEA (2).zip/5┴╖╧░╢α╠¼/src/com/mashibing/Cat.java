package com.mashibing;

public class Cat extends Pet {

    @Override
    public void feed() {
        System.out.println("猫在吃鱼");
    }
}
