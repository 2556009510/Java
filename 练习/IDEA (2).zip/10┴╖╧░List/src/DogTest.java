import java.util.ArrayList;
import java.util.List;

public class DogTest {
    public static void main(String[] args) {

//        List list = new ArrayList();
//        Dog d1 = new Dog("AA","aa");

        List list = new ArrayList();
        Dog d1 = new Dog("AA","aa");
        Dog d2 = new Dog("BB","bb");
        Dog d3 = new Dog("CC","cc");
        list.add(d1);
        list.add(d2);
        list.add(d3);

        System.out.println(list);
        System.out.println(list.size());

        list.remove(d1);  /** 删除d1集合 */
        System.out.println(list);

        /** 判断集合中是否包含b4一样的 */
        Dog d4 = new Dog("BB","bb");
        System.out.println(list.contains(d4));
    }
}
