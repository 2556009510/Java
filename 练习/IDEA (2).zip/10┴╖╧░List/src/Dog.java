import java.util.Objects;

public class Dog {
    private String name;
    private String s;

    public Dog(){}
    public Dog(String name, String s){
        this.name = name;
        this.s = s;
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getS() {
        return s;
    }
    public void setS(String s) {
        this.s = s;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Dog dog = (Dog) o;
        return name.equals(dog.name) &&
                s.equals(dog.s);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, s);
    }

    @Override
    public String toString() {
        return "Dog{" +
                "name='" + name + '\'' +
                ", s='" + s + '\'' +
                '}';
    }
}



