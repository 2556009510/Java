package aaa;
public interface Lock{

//    public abstract void openDoor();
//    public abstract void closeDoor();
    void openLock();
    void closeLock();      /** Dooor与Lock分开写，方便管理 */
}
