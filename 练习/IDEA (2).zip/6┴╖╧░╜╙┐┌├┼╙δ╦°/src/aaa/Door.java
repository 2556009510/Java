package aaa;
public abstract class Door {

    public abstract void openDoor();
    public abstract void closeDoor();
    /** 上面的Dooor与下面的Lock分开写，方便管理 */
//    public abstract void openLock();
//    public abstract void closeLock();
}
