package aaa;
public class Test {
    public static void main(String[] args) {

        LockDoor ld = new LockDoor();
        ld.openDoor();
        ld.closeDoor();
        ld.openLock();
        ld.closeLock();

        AA aa = new AA();
        aa.openLock();
        aa.closeLock();
    }
}
