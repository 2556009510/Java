package aaa;
public class AA implements Lock{

    @Override
    public void openLock() {
        System.out.println("AA");
    }
    @Override
    public void closeLock() {
        System.out.println("BB");
    }
}
