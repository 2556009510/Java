public class TestSum {
    public static void main(String[] args) {
        System.out.println(sum(40));
    }

    public static long sum(int n) {
        if (n <= 0) {
            return 0;
        } else if (n == 1 || n == 2) {
            return 1;
        } else {
            return sum(n - 1) + sum(n - 2);  /**  上一个值 + 上上一个值 = 现在的值 */
        }
    }
}
