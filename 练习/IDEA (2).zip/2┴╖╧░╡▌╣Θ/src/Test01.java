import java.util.Scanner;

public class Test01 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        /** 输入一个数 */
        System.out.println("请输入你要判断的数据：");
        int n = sc.nextInt();
        if (n > 10 || n < 1) {
            System.out.println("限制输入的数据在1-10之间");
            System.exit(0);
        }
//==========================================================================
        String str = testString(n);
        long sum = factRec(n);      /** 递归 */
        System.out.println(n + "!=" + str + "=" + sum);
//==========================================================================
        long sum2 = factfor(n);     /** for循环 */
        System.out.println(n + "!=" + str + "=" + sum2);
//==========================================================================
    }



//==========================================================================
    /** 实现字符串的输出 */
    public static String testString(int n){
        String result = "";
        for (int i=1;i<=n;i++){
            result +=(i+"*");
        }
        return result.substring(0, result.length()-1);
    }
//==========================================================================
    /** 递归实现 */
    public static long factRec(int n){
        if(n==1){
            return 1;
        }else{
            return n*factRec(n-1);
        }
    }
//==========================================================================
    /** for循环实现 */
    public static long factfor(int n){
        int sum = 1;
        for (int i = 1; i < n; i++) {
            sum += sum * i;
        }
        return sum;
    }
//==========================================================================
}


