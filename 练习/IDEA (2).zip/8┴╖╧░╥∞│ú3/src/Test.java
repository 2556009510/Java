import java.util.Scanner;
public class Test {
    public static void main(String[] args) {
        try {
            BB();
        } catch (GenderException e) {
            e.printStackTrace();
        }
        System.out.println("hehe");
    }

    public static void BB() throws GenderException {
//        Scanner sc = new Scanner(System.in);
//        int a = sc.nextInt();
        String a = "1234";
        if (a.equals("man")) {
            System.out.println("语文");
        } else if (a.equals("woman")) {
            System.out.println("数学");
        } else {
            throw new GenderException("性别异常");
        }
    }
}