//public class Employee {
//    private int g;         //工号
//    private String name;
//    private int age;
//
//    public Employee(){}
//    public Employee(int g, String name, int age) {
//        this.g = g;
//        this.name = name;
//        this.age = age;
//    }
//
//    public int getG() {
//        return g;
//    }
//    public void setG(int g) {
//        this.g = g;
//    }
//
//    public String getName() {
//        return name;
//    }
//    public void setName(String name) {
//        this.name = name;
//    }
//
//    public int getAge() {
//        return age;
//    }
//    public void setAge(int age) {
//        this.age = age;
//    }
//
//    @Override
//    public String toString() {
//        return "Employee{" +
//                "g=" + g +
//                ", name='" + name + '\'' +
//                ", age=" + age +
//                '}';
//    }
//}
