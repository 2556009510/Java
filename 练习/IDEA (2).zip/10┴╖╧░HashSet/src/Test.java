import java.util.HashSet;
import java.util.Set;

//public class Test {
//    public static void main(String[] args) {
//
//        Set s = new HashSet();
//        System.out.println("本单位共有员工人数为："+s.siez());
//        System.out.println("人员内容分别如下：");
//
//        Employee e1 = new Employee();
//        e1.setG(1002);
//        e1.setName("李幽默");
//        e1.setAge(22);
//        System.out.println(e1);
//
//        Employee e2 = new Employee();
//        e2.setG(1001);
//        e2.setName("王小花");
//        e2.setAge(20);
//        System.out.println(e2);
//
//        Employee e3 = new Employee();
//        e3.setG(1003);
//        e3.setName("张一慢");
//        e3.setAge(24);
//        System.out.println(e3);
//        System.out.println("======================================");
//
//        System.out.println("======================================");
//
//
//    }
//}
