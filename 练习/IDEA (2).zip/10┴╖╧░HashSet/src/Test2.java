import java.util.HashSet;

public class Test2 {
    public static void main(String[] args) {
        HashSet<Employee> set = new HashSet<Employee>();
        Employee e1 = new Employee(1001,"张三",12);
        Employee e2 = new Employee(1002,"李四",14);
        Employee e3 = new Employee(1003,"王五",16);
        set.add(e1);
        set.add(e2);
        set.add(e3);

        for (Employee employee : set) {
            System.out.println(employee);
        }
        System.out.println("=====================================================");
        set.remove(e1);


        for (Employee employee : set) {
            System.out.println(employee);
        }
        System.out.println("=====================================================");


        if (set.contains(e2)){
            System.out.println("包含");
        }else{
            System.out.println("不包含");
        }
    }
}

class Employee{
    private int id;
    private String name;
    private int age;

    public Employee() {
    }
    public Employee(int id, String name, int age) {
        this.id = id;
        this.name = name;
        this.age = age;
    }

    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }
    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", age=" + age +
                '}';
    }
}