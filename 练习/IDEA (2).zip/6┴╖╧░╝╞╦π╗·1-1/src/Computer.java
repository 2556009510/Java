public  interface Computer {
    public void cpuBrand();  // CPU品牌
    public void gbCapacity(); // 硬盘容量
    public void ramCapacity(); // 内存容量



}
