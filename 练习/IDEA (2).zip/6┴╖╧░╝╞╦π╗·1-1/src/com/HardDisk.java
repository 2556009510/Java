package com;
public interface HardDisk {
    public String getVolumn();
}
