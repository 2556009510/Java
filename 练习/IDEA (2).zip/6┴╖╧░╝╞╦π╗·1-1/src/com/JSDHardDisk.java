package com;
public class JSDHardDisk implements HardDisk {

    @Override
    public String getVolumn() {
        return "400G";
    }
}
