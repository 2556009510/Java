package com;
public class Kingston implements Memory{

    @Override
    public String getCapacity() { return "10G"; }
}
