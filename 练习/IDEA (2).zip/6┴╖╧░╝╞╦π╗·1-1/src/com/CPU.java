package com;
public interface CPU {
//    public static final String str = "hehe";
    public String getBrand();
    public String getHZ();
}
