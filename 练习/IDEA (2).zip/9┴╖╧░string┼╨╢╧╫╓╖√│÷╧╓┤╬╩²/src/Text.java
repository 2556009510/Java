import java.util.Scanner;

public class Text{
    public static void main(String[] args){
        String a = "我爱你中国,我爱你长城,大爱无疆";
        Scanner sc = new Scanner(System.in);
        String b = sc.nextLine();
        String c = a.replaceAll("\\Q" + b + "\\E","");
        int d = (a.length() - c.length()) / b.length();
        System.out.printf("'%s' 在 '%s' 中出现的次数是:%d",b,a,d);
    }
}
