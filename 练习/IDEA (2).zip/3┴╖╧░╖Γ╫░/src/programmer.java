public class programmer {
    private String name;
    private int age;
    private String direction;
    private int seniority;
    private String profession;
    private String DBA;

    public programmer(){}
    public programmer(String name,int age,String direction,int seniority,String profession,String DBA){
        this.name = name;
        this.age = age;
        this.direction = direction;
        this.seniority = seniority;
        this.profession = profession;
        this.DBA = DBA;
    }
    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name = name;
    }

    public int getAge(){
        return age;
    }
    public void setAge(int age){
        if(age < 20){
            this.setAge(20);
            System.out.println("年龄信息无效!已修改默认年龄为15");
        }else{
            this.age = age;
        }
    }

    public String getDirection(){
        return direction;
    }
    public void setDirection(String direction){
        this.direction = direction;
    }

    public int getSeniority(){
        return seniority;
    }
    public void setSeniority(int seniority){
        this.seniority = seniority;
    }

    public String getProfession(){
        return profession;
    }
    public void setProfession(String profession){
        this.profession = profession;
    }

    public String getDBA(){
        return DBA;
    }
    public void setDBA(String  DBA){
        this.DBA = DBA;
    }

    public void it(){
        System.out.println("姓名："+name);
        System.out.println("年龄："+age);
        System.out.println("技术方向："+direction);
        System.out.println("工作年限："+seniority);
        System.out.println("目前就职于："+profession);
        System.out.println("职务是："+DBA);
    }
}
class TestProgrammer {
    public static void main(String[] args) {
        programmer p1 = new programmer();
        p1.setName("马卫龙");
        p1.setAge(10);           /** 10岁改成20，因为private  所以不能直接在第二个programmer方法的写if（） */
        p1.setDirection("数据库维护");
        p1.setSeniority(1);
        p1.setProfession("阿里巴巴");
        p1.setDBA("数据库维护工程师");
        p1.it();
        System.out.println("===============================================");

        programmer p2 = new programmer("王硕", 10, "JAVA开发", 2, "腾讯科技", "Java开发工程师");
        p2.it();
    }
}

