public class Monster {
    private  String name;   // 名字
    private  int AA;        // 生命值
    private  int BB;        // 攻击力

    public String getName() { return name; }
    public void setName(String name){
        this.name = name;
    }

    public int getAA() { return AA; }
    public void setAA(int AA) {
        this.AA = AA;
    }

    public int getBB() { return BB; }
    public void setBB(int BB) {
        this.BB = BB;
    }

    public void attack() {
        System.out.println("怪物"+this.getName()+"展开攻击");
        System.out.println("当前生命值："+this.getAA());
        System.out.println("攻击力是："+this.getBB());
    }
    public void move() { }
}
