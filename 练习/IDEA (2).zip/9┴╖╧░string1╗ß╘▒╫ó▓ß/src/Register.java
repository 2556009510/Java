import java.util.Scanner;

public class Register {
    String yonghu;
    String mima;
    String mima2;

    public void verify() {
        Scanner sc = new Scanner(System.in);
        System.out.println("请输入用户名：");
        yonghu = sc.next();

        System.out.println("请输入密码：");
        mima = sc.next();

        System.out.println("请再次输入密码：");
        mima2 = sc.next();
        while ((yonghu.length())< 3|| (mima.length())<6|| mima.equals(mima2) == false ) {
            if (yonghu.length()<3){
                System.out.println("用户名长度不能小于3,请重新输入：");
                yonghu = sc.next();
            }
            if (mima.length()<6){
                System.out.println("密码长度不能小于6,请重新输入：");
                mima = sc.next();
            }
            if (mima.equals(mima2)==false){
                System.out.println("两次密码不想同,请重新输入：");
                mima2 = sc.next();
            }
        }
    }
    public void ti(){
        System.out.println("用户名："+yonghu);
        System.out.println("密码："+mima);
    }
}

class Test {
    public static void main(String[] args) {
        Register r = new Register();
        r.verify();
        r.ti();
    }
}

