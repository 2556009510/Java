public class TryTest3{            /** finally中改变返回值num */
    public static void main(String[] args){
        System.out.println(test());
    }

    private static int test(){
        int num = 10;
        try{
            System.out.println("try");
            return num;                  /** 没有输出该值 */
        }catch(Exception e){
            System.out.println("error");
        }finally{
            if (num > 20){
                System.out.println("num>20 : " + num);
            }
            System.out.println("finally");
            num = 100;
        }
        return num;
    }
}
