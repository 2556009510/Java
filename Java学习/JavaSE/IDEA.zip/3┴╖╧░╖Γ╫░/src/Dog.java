public class Dog {
    private String strain;
    private int age;
    private String mood;
    private String name;

    public Dog() { super(); /** super不用写也可以？ */ }
    public Dog(String breed,int age,String mood,String name) {
        super();  /** super不用写也可以？ */
        this.strain = breed;
        this.age = age;
        this.setMood(mood);   /** 或this.mood = mood */
        this.name = name;
    }
    public String getStrain() {
        return strain;
    }
    public void setStrain(String strain) {
        this.strain = strain;
    }
    public int getAge() {
        return age;
    }
    public void setAge(int age) {
        this.age = age;
    }
    public String getMood() {
        return mood;
    }
    public void setMood(String mood) {
        if ("心情好".equals(mood)||"心情不好".equals(mood)){
            this.mood = mood;
        }else {
            System.out.println("你输入信息有误");
            this.mood = "心情好11111";
        }
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public void call(){
        if ("心情好".equals(mood)){
            System.out.println("名字叫"+name+"的"+strain+mood+",开心的汪汪叫");
        }else {
            System.out.println("名字叫"+name+"的"+strain+mood+",伤心的呜呜叫");
        }
    }
    public void run(){
        if ("心情好".equals(mood)){
            System.out.println("名字叫"+name+"的"+strain +mood+",开心的围着主人身边转");
        }else{
            System.out.println("名字叫"+name+"的"+strain+mood+",伤心的一动不动");
        }
    }
}

class Test{
    public static void main(String[] args) {
        Dog p1 = new Dog();
        p1.setStrain("哈士奇");
        p1.setAge(2);
        p1.setMood("好");
        p1.setName("哈达迪");
        p1.call();
        p1.run();
        System.out.println("==========================================");
        Dog p2 = new Dog("德国牧羊犬", 3, "心情不好", "太子");
        p2.call();
        p2.run();
    }
}
