public class Computer implements CPU,GB,RAM{
    public void show(CPU cpu,GB gb,RAM ram){          /** 参数写接口名 */
        System.out.println("计算计算机的信息如下：");
        System.out.println("CPU的品牌是："+cpu.Brand()+",主频是："+cpu.GH());/** cpu.+ 被接口的方法  */
        System.out.println("硬盘容量是："+gb.GBcapacity());     /** gb.+ 被接口的方法  */
        System.out.println("内存容量是："+ram.RAMcapacity());   /** ram.+ 被接口的方法  */
    }

    @Override
    public String Brand() {
        return null;
    }
    @Override
    public String GH() {
        return null;
    }
    @Override
    public String GBcapacity() {
        return null;
    }
    @Override
    public String RAMcapacity() {
        return null;
    }
}
