public interface GB {
    public String GBcapacity();


}
