public class GBa implements GB{

    @Override
    public String GBcapacity() { return "100G"; }
}
