package com.mashibing;

/**
 * @author: 马士兵教育
 * @create: 2019-08-31 16:03
 */
public abstract class Pet {
    public abstract void feed();

    public void play(){
        System.out.println("playing.....");
    }
}
