package com.mashibing;

/**
 * @author: 马士兵教育
 * @create: 2019-08-31 16:04
 */
public class Dog extends Pet {

    @Override
    public void feed() {
        System.out.println("狗在吃骨头");
    }
}
