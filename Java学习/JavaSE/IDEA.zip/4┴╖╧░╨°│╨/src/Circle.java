public class Circle {
    private double radius;

    public Circle(){  /** 将半径设为0*/
        this.radius = 0;
    }
    public Circle(double r){  /** 将半径初始化为r */
        this.radius = r;
    }
    public double getArea(){  /** 获取圆的面积 */
        return Math.PI * this.radius * this.radius ;
    }
    public double getPerimeter(){  /** 获取圆的周长 */
        return Math.PI * this.radius * 2 ;
    }
    /** 将圆的关径、周长、面积输出到屏幕 */
    public void show(){
        System.out.println("圆的半径为："+this.radius);            //    用  get方法名  才能这样写 this.方法名
        System.out.println("圆的面积为："+this.getArea());         //
        System.out.println("圆的周长为："+this.getPerimeter());    //
    }
}
class Cylinder extends Circle{    /** 用 extends 续承后上面 get方法名 的大括号就不会报错 */

    /** 构造时设置圆的高，并调用父类的构造设置半径 */
    private double hight;

    public Cylinder(double r,double h){
        /** 直接引用父类对象 */
        super(r);
        this.hight = h;
    }
    public double getVolume(){   /** 获取圆柱体的体积 */
        /** 直接引用父类对象 */
        double s = super.getArea();
        return s * hight;
    }
    public void showVolume(){   /** 将圆柱体的体积输出到屏幕 */
    /** 直接引用父类对象 */
        super.show();
        System.out.println("圆的体积是："+this.getVolume());
    }
}
class Test{
    public static void main(String[] args) {
        Cylinder c = new Cylinder(10,10);
        c.showVolume();
    }
}
