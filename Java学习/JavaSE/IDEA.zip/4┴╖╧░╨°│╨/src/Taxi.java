public class Taxi extends Car{
    //String A;  // 车型
    //int B;     // 车牌
    private  String C;  // 出租车公司

/** 不能用void */
    public Taxi(String C){ this.C = C; }

    /** 使用启动方法 */
    public void start(){
        System.out.println("乘客您好\n我是"+this.C+ "的，我的车牌号是"+this.getB()+"，你要去那里？");
    }
    /** 使用停止方法 */
    public void stop(){
        System.out.println("目的地已经到了，请您下车付款，欢迎再次乘坐");
    }
}
