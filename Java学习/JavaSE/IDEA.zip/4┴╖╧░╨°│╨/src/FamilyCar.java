public class FamilyCar extends Car{
    //String AA;        // 车型
    //int BB;           // 车牌
    private  String carName;  // 车主名字

/** 不能用void */
    public FamilyCar(String carName){
        this.carName = carName;
    }

    /** 使用启动方法 */
    public void start(){
        System.out.println("我是"+carName+"，我的汽车我做主");
    }
    /** 使用停止方法 */
    public void stop(){
        System.out.println("目的地到了，我们去玩吧");
    }
}
