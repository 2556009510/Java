import java.util.Scanner;

public class Register {
    private String yonghu;
    private String mima;
    private String mima2;

    public void verify() {
        Scanner sc = new Scanner(System.in);
        System.out.println("*************欢迎注册");
        String yonghu = sc.nextLine();
        while (yonghu.length() < 3){
            System.out.println("用户名长度小于3");
            yonghu = sc.nextLine();
        }
        String mima = sc.nextLine();
        while (mima.length() < 3){
            System.out.println("密码长度小于6");
            mima = sc.nextLine();
        }
        String mima2 = sc.nextLine();
        while (mima != mima2){
            System.out.println("两次输入密码不一致");
            mima2 = sc.nextLine();
        }

        System.out.println("用户名是："+yonghu);
        System.out.println("密码是："+mima);
    }
}

