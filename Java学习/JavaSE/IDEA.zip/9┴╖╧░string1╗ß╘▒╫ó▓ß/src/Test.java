
public class Test {
    public static void main(String[] args) {
        Register r = new Register();
        r.verify();


    }

}
