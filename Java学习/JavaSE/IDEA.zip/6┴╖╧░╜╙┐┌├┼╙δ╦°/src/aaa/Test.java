package aaa;
public class Test {
    public static void main(String[] args) {

        LockDoor ld = new LockDoor();
        ld.openDoor();
        ld.closeDoor();
        ld.openLock();
        ld.closeLock();

        AA aa = new AA();   /** 一个类一个.. .. = new ..(); */
        aa.openLock();
        aa.closeLock();

    }
}
