public abstract class Pet {           // 抽象
    public abstract void feed();      // 抽象
}
