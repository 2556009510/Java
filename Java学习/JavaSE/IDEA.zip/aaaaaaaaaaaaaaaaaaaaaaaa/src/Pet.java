public abstract class Pet {
    public abstract void feed();

    public void aa(){
        System.out.println("333333");
    }
}
