public class Cat extends Pet{
    public void feed(){
        System.out.println("111");
    }
}
