public class Test {
//    public void feed(Dog dog){
//        dog.feed();
//    }
//    public void feed(Cat cat){
//        cat.feed();
//    }
//
    public void feed(Pet pet){
        pet.feed();
    }

    public void aaa(Pet p){
       p.aa();
    }

    public static void main(String[] args) {
        Test t = new Test();
        Cat c = new Cat();
        Dog d = new Dog();
        t.feed(c);
        t.feed(d);

        t.aaa(c);
        t.aaa(d);
    }
}
