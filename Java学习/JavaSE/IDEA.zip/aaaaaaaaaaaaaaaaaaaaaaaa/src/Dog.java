public class Dog extends Pet{
    public void feed(){
        System.out.println("222");
    }
}
