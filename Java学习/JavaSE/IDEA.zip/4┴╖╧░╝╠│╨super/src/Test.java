public class Test {
    public static void main(String[] args) {
        new ChildClass().f();
    }
}
class FatherClass {
    public int value;

    public void f(){
        value = 111;
        System.out.println("FatherClass.value = "+value);
    }
}
class ChildClass extends FatherClass {
    public int value;

    public void f(){
        super.f();
        value = 222;
        System.out.println("ChildClass.value = "+value);
        System.out.println("=============================================");


        System.out.println(value);
        System.out.println(super.value);   /** super 用到的是父类中 value */
    }
}