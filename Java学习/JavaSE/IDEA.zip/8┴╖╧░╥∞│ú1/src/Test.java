import java.util.Scanner;

public class Test {
//    public void AA(String aa){
//
//
//    }
    public static void main(String[] args) {

//        Scanner sc = new Scanner(System.in);

        try{
//            System.out.println("请输入被除数");
            String a = "c";                       /** 强制转换 */
//            System.out.println("请输入除数");
            int b = Integer.parseInt(a);          /** 强制转换 */
//            System.out.println(String.format("%d/%d=%d",a,b,a/b));
            System.out.println(b);                /** 强制转换 */

            System.out.println("前面没有出现异常");
        }catch(NumberFormatException e){
            System.out.println("异常11111111111111111111111111111111111111");
            e.printStackTrace();
            System.out.println(e.getMessage());
        }catch (Exception e){
            System.out.println("异常22222222222222222222222222222222222222");
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
        System.out.println("感谢使用");
    }
}
