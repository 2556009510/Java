public class Cpu implements Comparable{


    @Override
    public int compareTo(Object o) {
        return 0;
    }
}
