public class RAM implements Comparable{

    @Override
    public int compareTo(Object o) {
        return 0;
    }
}
