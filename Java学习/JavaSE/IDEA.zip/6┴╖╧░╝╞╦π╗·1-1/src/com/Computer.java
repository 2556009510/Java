package com;
public class Computer implements CPU,HardDisk,Memory{

    public void show(CPU cpu,HardDisk hardDisk,Memory memory){
        System.out.println("计算机的组成如下：");
        System.out.println("cpu:"+cpu.getBrand()+"  ,主频是："+cpu.getHZ());
        System.out.println("硬盘容量是："+hardDisk.getVolumn());
        System.out.println("内存容量是："+memory.getCapacity());
    }

    @Override
    public String getBrand() {
        return null;
    }
    @Override
    public String getHZ() {
        return null;
    }
    @Override
    public String getVolumn() {
        return null;
    }
    @Override
    public String getCapacity() {
        return null;
    }
}
