package com;
public class SXHardDisk implements HardDisk{

    @Override
    public String getVolumn() {
        return "5000G";
    }
}