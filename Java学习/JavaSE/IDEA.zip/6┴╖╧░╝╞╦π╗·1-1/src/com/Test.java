package com;
public class Test {
    public static void main(String[] args) {
        Computer computer = new Computer();
        CPU cpu = new InterCpu();
        HardDisk hardDisk =  new JSDHardDisk();
        Memory memory = new Kingston();
        computer.show(cpu,hardDisk,memory);
    }
}