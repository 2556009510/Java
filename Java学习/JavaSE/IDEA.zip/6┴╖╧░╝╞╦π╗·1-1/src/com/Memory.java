package com;
public interface Memory {
    public String getCapacity();
}