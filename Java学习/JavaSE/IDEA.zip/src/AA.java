public class AA {

    public class Inner{
        public void print(){
            System.out.println("hello");
        }
    };

//    public void show(){
//        Inner.print();
//    }
};
