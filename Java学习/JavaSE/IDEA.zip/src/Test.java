public class Test {
    public static void main(String[] args) {

        AA aa = new AA();
        AA.Inner inner = aa.new Inner();

        inner.print();

//    aa.show();
    }
}
