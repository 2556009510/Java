public class GenderException extends Test{
    public void GenderException(){
        System.out.println("异常111");
    }
    public void GenderException(String age){
        System.out.println(age);
    }
}
