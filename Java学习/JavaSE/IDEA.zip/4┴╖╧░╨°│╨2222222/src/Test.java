public class Test {
    public static void main(String[] args) {
        //Centipede ce = new Centipede();

        Serpent s = new Serpent();
        s.setName("");
        s.setAA(5);
        s.setBB(20);
        s.attack();
        if (s.getAA() < 10) {//当生命少于10时，加20血
            s.addAA();
        }
        s.move();
        System.out.println("=======================");

        Centipede c = new Centipede();
        c.setName("");
        c.setAA(60);
        c.setBB(15);
        c.attack();
        c.move();
    }
}
