public class Centipede extends Monster {

//    public String getName() { return name; }
//    public void setName(String name){
//        this.name = name;
//    }
//    public void attack(){
//        System.out.println("怪物蜈蚣乙展开攻击");
//        System.out.println("攻击力是："+this.AA);
//        System.out.println("当前生命值是："+this.BB);
//
//    }

    public void move(){
        System.out.println("我是蜈蚣精，御风飞行");
    }
}
