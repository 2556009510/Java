public class Serpent extends Monster{

    public void addAA(){
        this.setAA(this.getAA()+20);
        System.out.println("实施大蛇补血术......，当前的生命值是"+this.getAA());
    }
    public void move(){
        System.out.println("我是蛇怪，我走S型路线");
    }
}
